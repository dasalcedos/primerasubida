/*Se declaran los cursos de extension que ofece le Tecnologico de antioquia*/

let cursosExtension = {
    cursos: [{

        id: "Ingles1",
        nombre: "Cursos de inglés nivel 1",
        duracion: " 64 Horas",
        valor: 410000
    },

    {

        id: "gen1",
        nombre: "Curso interpretación de pruebas genéticas en procesos judiciales",
        duracion: " 48 Horas",
        valor: 295000
    },
    {

        id: "Sport1",
        nombre: "Escuela de iniciación deportiva",
        duracion: " 1 Semestre",
        valor: 135000
    }
    ]
};

module.exports = {
    cursosExtension

};